package com.example.yaraswork

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
